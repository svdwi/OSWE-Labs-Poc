###############################################################
# Database upgrade SQL from ATutor 1.5.3 to ATutor 1.5.3.1
###############################################################

INSERT INTO `modules` VALUES ('_standard/blogs',         2, 0, 0, 0, 0);
