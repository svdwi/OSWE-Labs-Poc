<?php require('../common/body_header.inc.php'); $lm = '$LastChangedDate$'; ?>

<h2>My Account</h2>
	<p><em>My Account</em> allows the Administrator to change his/her account password, name, or email address.</p>

<?php require('../common/body_footer.inc.php'); ?>