<?php require('../common/body_header.inc.php'); $lm = '$LastChangedDate$'; ?>

<h2>Error Logging</h2>
	<p>Error logging is available to administrators as a trouble shooting tool. Should the system be giving error messages, a daily list of these errors are collected and available for review or to be bundled up and sent to the ATutor team for investigation. When using the atutor.ca support forums, attaching any error logs may be helpful in finding solutions to problems on your system.</p>

<?php require('../common/body_footer.inc.php'); ?>
