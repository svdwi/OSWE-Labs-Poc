<?php require('../common/body_header.inc.php'); $lm = '$LastChangedDate: 2006-07-01 18:04:33 -0400 (Sat, 01 Jul 2006) $'; ?>

<h2>Network Groups</h2>

<p>Network Groups can be created by anyone, for any purpose. They are a place to post information and discuss common interests. You may search for groups and join them. Once you have created or joined a group, you can <strong>Invite</strong> others to join, and view a list of people in the group. If you created the group, you also have the option to disband it.</p>

<?php require('../common/body_footer.inc.php'); ?>
