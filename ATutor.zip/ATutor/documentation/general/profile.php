<?php require('../common/body_header.inc.php'); $lm = '$LastChangedDate$'; ?>

<h2>Profile</h2>
<p>This section allows a user to change elements of his/her personal profile.</p>

<p>Although the login name cannot be altered, password, email address, and other personal information may be edited. There is also an option to keep the email address hidden.</p>

<?php require('../common/body_footer.inc.php'); ?>