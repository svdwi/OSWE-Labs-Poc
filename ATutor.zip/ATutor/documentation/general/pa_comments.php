<?php require('../common/body_header.inc.php'); $lm = '$LastChangedDate: 2006-07-01 18:04:33 -0400 (Sat, 01 Jul 2006) $'; ?>

<h2>Comments</h2>

<p>Users can post comments to an album or a photo.  The author of a comment can edit it by clicking on the comment itself, the comment will turn into an editable field.  When done editing, press Enter to save the changes.  Note: The owner of the album can edit and delete any comments within the album.  </p>

<?php require('../common/body_footer.inc.php'); ?>
