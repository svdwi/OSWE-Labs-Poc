<?php require('../common/body_header.inc.php'); $lm = '$LastChangedDate$'; ?>

<h2>Login</h2>

<p>A user may login to the system with the Login Name or Email address, and the Password entered during <a href="register.php">registration</a>. Logging in gives users access to Protected courses, lets them enroll, and lets them participate in courses.</p>

<?php require('../common/body_footer.inc.php'); ?>
