<?php require('../common/body_header.inc.php'); $lm = '$LastChangedDate: 2006-06-29 11:25:07 -0400 (Thu, 29 Jun 2006) $'; ?>

<h2>Authenticated Access</h2>
	<p>Since version 1.5.4, instructors may enable this feature to generate a unique <acronym title="Uniform Resource Identifier">URI</acronym> that may be distributed to authenticate guest access to the protected or private course.</p>

<?php require('../common/body_footer.inc.php'); ?>