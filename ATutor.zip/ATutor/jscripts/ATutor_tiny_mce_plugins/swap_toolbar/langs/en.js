tinyMCE.addI18n('en.swap_toolbar_simple',{
	desc : 'Hide toolbars'
});

tinyMCE.addI18n('en.swap_toolbar_complex',{
	desc : 'More toolbars'
});
